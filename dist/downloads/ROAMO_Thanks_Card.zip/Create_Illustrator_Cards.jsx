#target illustrator
(function () {
    var root = File($.fileName).parent;
    var jobs = [{"name": "01_Thanks_Card_Front", "w": 111, "h": 154, "layers": ["BACKGROUND", "FRAME", "LOGO", "TYPE_OUTLINES", "DUNE_PATTERN", "SAFE", "TRIM", "BLEED"]}, {"name": "02_Thanks_Card_Back", "w": 111, "h": 154, "layers": ["BACKGROUND", "TYPE_OUTLINES", "DECOR", "SAFE", "TRIM", "BLEED"]}];
    var targetFolder = new Folder(root.fsName + "/AI_Output");
    if (!targetFolder.exists && !targetFolder.create()) throw new Error("Cannot create AI_Output folder.");
    var mm = 72 / 25.4, completed = [];
    function topItems(doc) {
        var out = [];
        for (var i = 0; i < doc.pageItems.length; i++) {
            var p = doc.pageItems[i];
            if (p.parent.typename === "Layer") out.push(p);
        }
        return out;
    }
    try {
        for (var j = 0; j < jobs.length; j++) {
            var job = jobs[j];
            var doc = app.documents.add(DocumentColorSpace.RGB, job.w * mm, job.h * mm);
            var initial = doc.layers[0];
            for (var n = 0; n < job.layers.length; n++) {
                var name = job.layers[n];
                var f = new File(root.fsName + "/Layer_Sources/" + job.name + "/" + name + ".svg");
                if (!f.exists) throw new Error("Missing source: " + f.fsName);
                var source = app.open(f);
                var sr = source.artboards[0].artboardRect;
                var dr = doc.artboards[0].artboardRect;
                var items = topItems(source);
                var target = doc.layers.add(); target.name = name;
                // Preserve source stacking order and physical artboard registration.
                for (var k = items.length - 1; k >= 0; k--) {
                    var copied = items[k].duplicate(target, ElementPlacement.PLACEATBEGINNING);
                    copied.translate(dr[0] - sr[0], dr[1] - sr[1]);
                }
                source.close(SaveOptions.DONOTSAVECHANGES);
                doc.activate();
                target.printable = (name !== "TRIM" && name !== "SAFE" && name !== "BLEED");
                target.locked = (name === "TRIM" || name === "SAFE" || name === "BLEED");
            }
            if (initial.pageItems.length === 0) initial.remove();
            doc.activeLayer = doc.layers.getByName("TYPE_OUTLINES");
            var file = new File(targetFolder.fsName + "/" + job.name + ".ai");
            var suffix = 2;
            while (file.exists) file = new File(targetFolder.fsName + "/" + job.name + "_" + (suffix++) + ".ai");
            var opts = new IllustratorSaveOptions(); opts.pdfCompatible = true;
            doc.saveAs(file, opts); completed.push(file.name);
        }
        alert("Created editable Illustrator documents in AI_Output:\n" + completed.join("\n") + "\nTechnical layers are locked and non-printing. Unlock for editing; enable Print for a cutting proof.");
    } catch (e) { alert("Conversion stopped: " + e.message + "\nYou can still open the two main SVG files directly in Illustrator."); }
})();
